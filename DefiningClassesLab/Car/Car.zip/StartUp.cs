﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Numerics;
using System.IO;

namespace CarManufacturer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Car cars = new Car()
            {
                Make = "VW",
                Model = "MK3",
                Year = 1992
            };

            //Console.WriteLine($"Make: {cars.Make}\nModel: {cars.Model}\nYear: {cars.Year}");
        }
    }
}
