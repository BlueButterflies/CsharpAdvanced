﻿using System;

namespace GenericScale
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            //EqualityScale<int> test = new EqualityScale<int>(20, 5);
            //Console.WriteLine(test.AreEqual());
        }
    }
}