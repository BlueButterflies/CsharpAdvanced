﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Numerics;
using System.IO;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            //Person personOne = new Person();
            //Person personTwo = new Person(2);
            //Person personThree = new Person("Pesho", 30);
        }
    }
}
